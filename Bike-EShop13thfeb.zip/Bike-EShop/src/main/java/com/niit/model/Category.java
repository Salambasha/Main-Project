package com.niit.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Category {
	@Id
	private int id; 
	
	private String categoryDetails;
	
	@OneToMany(mappedBy="categoryDetails")
	private List<Product>Products;    
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCategoryDetails() {
		return categoryDetails;
	}

	public void setCategoryDetails(String categoryDetails) {
		this.categoryDetails = categoryDetails;
	}
	@Override
	public String toString() {
		return this.id + " " + this.categoryDetails;
	}
	

}

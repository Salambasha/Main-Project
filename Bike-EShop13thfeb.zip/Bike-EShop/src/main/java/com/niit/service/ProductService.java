package com.niit.service;

import com.niit.model.Product;

public interface ProductService {
	Product saveProduct(Product product);

}

package com.niit.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.niit.model.Product;
import com.niit.service.CategoryService;
import com.niit.service.ProductService;

@Controller
public class ProductController {

	public ProductController() {

		System.out.println("CREATING INSTANCE FOR product CONTROLLER");
	}
@Autowired
private ProductService productservice;
@Autowired
private CategoryService categoryservice;

	@RequestMapping("admin/product/productform")
	public String getProductForm(Model model) {
		model.addAttribute("product", new Product());
		model.addAttribute("categories", categoryservice.getCategories());
		return "ProductForm";
	}
	
	@RequestMapping("admin/product/addProduct")
public String saveProduct(@Valid @ModelAttribute(value="product") Product product,BindingResult result){
		if(result.hasErrors())
			return "ProductForm";
		Product newProduct=productservice.saveProduct(product);
	return "Succesful";
	
}

}

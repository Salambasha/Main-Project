package com.niit.dao;

import com.niit.model.Cart;

public interface CartDao {
	
	Cart getCart(int cartId);

}

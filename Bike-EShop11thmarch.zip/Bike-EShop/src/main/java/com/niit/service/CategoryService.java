package com.niit.service;

import java.util.List;

import com.niit.model.Category;

public interface CategoryService{
	
	List<Category> getCategories();
	Category getProductsByCategory(String category);

}

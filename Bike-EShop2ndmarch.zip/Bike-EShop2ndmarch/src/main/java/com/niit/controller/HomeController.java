package com.niit.controller;



import org.apache.log4j.Logger;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;




@Controller
public class HomeController {

	Logger logger = Logger.getLogger(HomeController.class);
	
	

	public HomeController() {
		
		//logger.debug("Creating the instance for home Controller");

		System.out.println("Creating the instance for home Controller");
	}

	@RequestMapping("/")
	public String homepage() {
		return "home";
	}

	
	@RequestMapping("/home")
	public String home(){
		
		return "home";	
	}

	@RequestMapping("/ContactUs")
	public String contact() {
		return "ContactUs";
	}

	@RequestMapping("/AboutUs")
	public String aboutus() {
		return "AboutUs";
	}

	@RequestMapping("/Login")
	public String login(@RequestParam(value="error",required=false) String error,
			@RequestParam(value="logout",required=false) String logout,	Model model){
		if(error!=null)
			model.addAttribute("error","Invalid Username and Password.. Please enter valid username and password");
		if(logout!=null)
			model.addAttribute("logout","Loggedout successfully..");
		return "LogIn";

	}

}

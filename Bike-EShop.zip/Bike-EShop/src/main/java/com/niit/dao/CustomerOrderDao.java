package com.niit.dao;

import com.niit.model.Cart;

public interface CustomerOrderDao {
	
	void addCustomerOrder(Cart cart);

}

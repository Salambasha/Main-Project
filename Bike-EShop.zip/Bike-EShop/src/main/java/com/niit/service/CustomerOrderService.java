package com.niit.service;

import com.niit.model.Cart;

public interface CustomerOrderService {
	void addCustomerOrder(Cart cart);

}
